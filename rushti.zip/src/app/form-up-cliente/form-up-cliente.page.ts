import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BancodedadosService } from '../services/bancodedados.service';

@Component({
  selector: 'app-form-up-cliente',
  templateUrl: './form-up-cliente.page.html',
  styleUrls: ['./form-up-cliente.page.scss'],
})
export class FormUpClientePage implements OnInit {

  routerId: string = null;
  cliente = {};

  constructor(
    private activedRouter: ActivatedRoute,
    private bd: BancodedadosService,
  ) { }

  ngOnInit() {
    this.routerId = this.activedRouter.snapshot.params['id'];
    
    if(this.routerId){
      this.bd.getClientes(this.routerId).subscribe(results => this.cliente = results);
    }

  }

   //Método de atualização
   atualizar(formUp){
    this.bd.upClientes(this.routerId,formUp.value);
    } 
}
