import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FormUpClientePage } from './form-up-cliente.page';

const routes: Routes = [
  {
    path: '',
    component: FormUpClientePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FormUpClientePageRoutingModule {}
