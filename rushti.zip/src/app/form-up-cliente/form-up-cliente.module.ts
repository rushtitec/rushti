import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FormUpClientePageRoutingModule } from './form-up-cliente-routing.module';

import { FormUpClientePage } from './form-up-cliente.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FormUpClientePageRoutingModule
  ],
  declarations: [FormUpClientePage]
})
export class FormUpClientePageModule {}
