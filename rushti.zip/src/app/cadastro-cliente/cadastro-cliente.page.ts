import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BancodedadosService } from '../services/bancodedados.service';

@Component({
  selector: 'app-cadastro-cliente',
  templateUrl: './cadastro-cliente.page.html',
  styleUrls: ['./cadastro-cliente.page.scss'],
})
export class CadastroClientePage implements OnInit {
  //variavel que armazena o grupo de informações vindas do formulario
  //formularioCliente: FormGroup;

  constructor(
    //ferramenta de validaçao
    /* private fb: FormBuilder,
    private bd: BancodedadosService */
  ) { } 
  
  ngOnInit() {
    //carrega o metodo na inicialização da página
    /* this.validarForm(); */
  }
//metodo que valida os dados do formulario
  /* private validarForm(){
    this.formularioCliente = this.fb.group({
      nome: ['',[Validators.required, Validators.minLength(2)]],
      cpf: ['',[Validators.required, Validators.minLength(11)]],
      endereco:['',[Validators.required, Validators.minLength(2)]],
      telefone:['', [Validators.required, Validators.minLength(2)]],
      email: ['',[Validators.required, Validators.minLength(2)]],
      password: ['',[Validators.required, Validators.minLength(6)]]
    });
   } */


   //metodo do botao do formulario
   /* salvar(){
     this.bd.cadClientes(this.formularioCliente.value);
   } */
}
