import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FormUpTecPageRoutingModule } from './form-up-tec-routing.module';

import { FormUpTecPage } from './form-up-tec.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FormUpTecPageRoutingModule
  ],
  declarations: [FormUpTecPage]
})
export class FormUpTecPageModule {}
