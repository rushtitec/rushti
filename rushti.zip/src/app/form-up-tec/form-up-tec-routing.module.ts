import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FormUpTecPage } from './form-up-tec.page';

const routes: Routes = [
  {
    path: '',
    component: FormUpTecPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FormUpTecPageRoutingModule {}
