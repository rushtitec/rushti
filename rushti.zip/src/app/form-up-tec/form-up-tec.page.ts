import { Component, OnInit } from '@angular/core';
import { BancodedadosService } from '../services/bancodedados.service';

@Component({
  selector: 'app-form-up-tec',
  templateUrl: './form-up-tec.page.html',
  styleUrls: ['./form-up-tec.page.scss'],
})
export class FormUpTecPage implements OnInit {
  listaTecnico = [];
  tecnico = {};
  cpf = '78956845721';

  constructor(
    private bd: BancodedadosService
  ) { }

  ngOnInit() {
    this.bd.getAllTecnico().subscribe(resultado => { this.listaTecnico = resultado;
      for(let i=0;  i < this.listaTecnico.length; i++){

        const tecnico1 = this.listaTecnico[i];
  
        if(tecnico1.cpf == this.cpf){
          this.tecnico = tecnico1;        }
      }
  
    });

    
    }
  }


