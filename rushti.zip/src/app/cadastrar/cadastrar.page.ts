import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BancodedadosService } from '../services/bancodedados.service';
import { IonSlides, LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-cadastrar',
  templateUrl: './cadastrar.page.html',
  styleUrls: ['./cadastrar.page.scss'],
})
export class CadastrarPage implements OnInit {

  @ViewChild(IonSlides, {static: false}) slide: IonSlides;

  loading: any;
  formularioCliente: FormGroup;
  formularioTecnico: FormGroup;

  constructor(
    private fb: FormBuilder,
    private bd: BancodedadosService,
    private loadingCtrl: LoadingController,
    private fbr: FormBuilder,
    private bdo: BancodedadosService
  ) { }

  ngOnInit() {
    this.validarForm();
    this.validarFormulario();
  }

  segmentMode(event){  
    if(event.detail.value === "cadastrar"){
      this.slide.slidePrev();
    }else{
      this.slide.slideNext();
    }
  }

  /* async loadingMessage(){
    this.loading = await this.loadingCtrl.create({message: 'Aguarde...'});
    return this.loading.present();
  } */


  private validarForm(){
    this.formularioCliente = this.fb.group({
      nome: ['',[Validators.required, Validators.minLength(2)]],
      cpf: ['',[Validators.required, Validators.minLength(1)]],
      endereco:['',[Validators.required, Validators.minLength(2)]],
      telefone:['', [Validators.required, Validators.minLength(2)]],
      email: ['',[Validators.required, Validators.minLength(2)]],
      password: ['',[Validators.required, Validators.minLength(6)]]
    });
   }

   private validarFormulario(){
    this.formularioTecnico = this.fbr.group({
      nome: ['',[Validators.required, Validators.minLength(6)]],
      cpf: ['',[Validators.required, Validators.minLength(2)]],
      endereco:['',[Validators.required, Validators.minLength(2)]],
      telefone:['', [Validators.required, Validators.minLength(2)]],
      email: ['',[Validators.required, Validators.minLength(2)]],
      formacao: ['',[Validators.required, Validators.minLength(2)]],
      experiencia: ['',[Validators.required, Validators.minLength(2)]],
      password: ['',[Validators.required, Validators.minLength(6)]]
    });
   }


   salvar(){
    this.bd.cadClientes(this.formularioCliente.value);
  }

  salvar1(){
    this.bdo.cadTecnico(this.formularioTecnico.value);
  }

}
