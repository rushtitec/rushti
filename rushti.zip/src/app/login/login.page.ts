import { Component, OnInit, ViewChild  } from '@angular/core';
import { IonSlides, LoadingController, AngularDelegate } from '@ionic/angular';
import { BancodedadosService } from '../services/bancodedados.service';
import { Router } from '@angular/router';
import { AngularFireModule } from '@angular/fire';




@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  @ViewChild(IonSlides, {static: false}) slide: IonSlides;
  loading: any;
  getAllClientes: any;

  autenticacao: AngularFireAuthModule ;
  email: string;
  senha: string;

  constructor(private service: BancodedadosService,
    private loadingCtrl: LoadingController,
    private routerCtrl: Router,
  ) { }

  ngOnInit() {
    this.service.getAllClientes().subscribe(dados => this.getAllClientes = dados);
  }

  segmentChanged(event){

    if(event.detail.value === 'login'){
      this.slide.slidePrev();
    }else{
      this.slide.slideNext();
    }
  }

  async loadingMessage(){
    this.loading = await this.loadingCtrl.create({message: 'Aguarde...'});
    return this.loading.present();
  }

  async userCad(formCad){
    await this.loadingMessage();
    this.service.cadClientes(formCad);
  }

  onLogin(formLogin){

    for(var i = 0; i < this.getAllClientes.length; i++){
      if( ( this.getAllClientes[i].email === formLogin.value.email)  && (this.getAllClientes[i].password === formLogin.value.password)){
        this.routerCtrl.navigate(['/tabs/tab1']);
        break;
      }else{
        console.log('Usuario não cadastrado!');
        break;
      }
    }
  }

}