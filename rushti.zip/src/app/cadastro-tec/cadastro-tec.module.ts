import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CadastroTecPageRoutingModule } from './cadastro-tec-routing.module';

import { CadastroTecPage } from './cadastro-tec.page';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    IonicModule,
    CadastroTecPageRoutingModule
  ],
  declarations: [CadastroTecPage]
})
export class CadastroTecPageModule {}
