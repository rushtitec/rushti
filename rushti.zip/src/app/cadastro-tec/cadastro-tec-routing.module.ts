import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CadastroTecPage } from './cadastro-tec.page';

const routes: Routes = [
  {
    path: '',
    component: CadastroTecPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CadastroTecPageRoutingModule {}
