import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BancodedadosService } from '../services/bancodedados.service';

@Component({
  selector: 'app-cadastro-tec',
  templateUrl: './cadastro-tec.page.html',
  styleUrls: ['./cadastro-tec.page.scss'],
})
export class CadastroTecPage implements OnInit {
  //variavel que armazena o grupo de informações vindas do formulario
  formularioTecnico: FormGroup;

  constructor(
    //ferramenta de validaçao
    private fbr: FormBuilder,
    private bdo: BancodedadosService
  ) { }

  ngOnInit() {
    //carrega o metodo na inicialização da página
    this.validarFormulario();
  }

  //metodo que valida os dados do formulario
  private validarFormulario(){
    this.formularioTecnico = this.fbr.group({
      nome: ['',[Validators.required, Validators.minLength(6)]],
      cpf: ['',[Validators.required, Validators.minLength(2)]],
      endereco:['',[Validators.required, Validators.minLength(2)]],
      telefone:['', [Validators.required, Validators.minLength(2)]],
      email: ['',[Validators.required, Validators.minLength(2)]],
      formacao: ['',[Validators.required, Validators.minLength(2)]],
      experiencia: ['',[Validators.required, Validators.minLength(2)]],
      password: ['',[Validators.required, Validators.minLength(6)]]
    });
   }

//metodo do botao do formulario
salvar(){
  this.bdo.cadTecnico(this.formularioTecnico.value);
}

}
