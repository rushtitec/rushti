import { Injectable } from '@angular/core';
import { AngularFirestoreCollection, AngularFirestore } from '@angular/fire/firestore/';
import { map } from 'rxjs/operators';
//import { User } from './user';
//import { HttpClient } from 'selenium-webdriver/http';
import { FirebaseApp, AngularFireModule } from '@angular/fire';


@Injectable({
  providedIn: 'root'
})
export class BancodedadosService {
  //variavel que contem as colções
 tecnicos: AngularFirestoreCollection;
 clientes: AngularFirestoreCollection;

  /* httpOptions = {
    headers: new AngularFireModule ({'Content-Type' : 'application/firebase'})
  } */

  constructor(
    /* private http: HttpClient, */
    //funcionario responsavel por verificar as coleçôes e atualizar no firebase
    private af: AngularFirestore
  ) { 
    this.clientes = this.af.collection('Clientes');
    this.tecnicos = this.af.collection('Tecnicos');
  }


  ////Banco de dados cliente

  //metodo de cadastro
  cadClientes(cliente){
    return this.clientes.add(cliente);
  }  

  //Metodo de consulta todos os dados
getAllClientes(){
  return this.clientes.snapshotChanges().pipe(
    map(actions => {
      return actions.map(a => {
        const data = a.payload.doc.data();
        const id = a.payload.doc.id;
        return {id, ...data}
      })
    })
  )
}

getClientes(id: string){
  return this.clientes.doc(id).valueChanges();
}

//Metodo que apaga um produto
dellClientes(id: string){
  return this.clientes.doc(id).delete();

}

//Metodo que atualiza um produto
upClientes(id, cliente){
  return this.clientes.doc(id).update(cliente);
}



//////////// Banco de dados Tecnico

//metodo de cadastro
cadTecnico(tecnico){
  return this.tecnicos.add(tecnico);
}

//Metodo de consulta todos os dados
getAllTecnico(){
return this.tecnicos.snapshotChanges().pipe(
  map(actions => {
    return actions.map(a => {
      const data = a.payload.doc.data();
      const id = a.payload.doc.id;
      return {id, ...data}
    })
  })
)
}

getTecnico(id: string){
return this.tecnicos.doc(id).valueChanges();
}

//Metodo que apaga um produto
delTecnico(id: string){
return this.tecnicos.doc(id).delete();
}

//Metodo que atualiza um produto
upTecnico(id, tecnico){
return this.tecnicos.doc(id).update(tecnico);
}

}
