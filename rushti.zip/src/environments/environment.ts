// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBniP5eX5FuDRFu3H4DrqboI37oK-lnuSs",
    authDomain: "rushti-2.firebaseapp.com",
    projectId: "rushti-2",
    storageBucket: "rushti-2.appspot.com",
    messagingSenderId: "1098959347533",
    appId: "1:1098959347533:web:687f46f4f72bf6392e2104"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
